package com.senai.exercicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
