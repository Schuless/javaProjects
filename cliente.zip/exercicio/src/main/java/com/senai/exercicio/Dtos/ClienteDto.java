package com.senai.exercicio.Dtos;

import java.time.LocalDate;

public class ClienteDto {

    private String Nome; //Nome do cliente.
    private String Email; //Email do cliente.
    private String Telefone;// Número de telefone do cliente.
    private String Endereço; //Endereço residencial do cliente.
    Integer numeroEndereco; //Número da residência do cliente.

    public ClienteDto() {
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    public String getEndereço() {
        return Endereço;
    }

    public void setEndereço(String Endereço) {
        this.Endereço = Endereço;
    }

    public Integer getNumeroEndereco() {
        return numeroEndereco;
    }

    public void setNumeroEndereco(Integer numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }
    
    
}
