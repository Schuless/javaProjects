package com.senai.exercicio.Repositório;

import com.senai.exercicio.Models.ClienteModel;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepositorio extends JpaRepository<ClienteModel, Long> {

    public Optional<ClienteModel> findByCliente(String cliente);

}
