package com.senai.exercicio.Service;

import com.senai.exercicio.Dtos.ClienteDto;
import org.springframework.stereotype.Service;

@Service
public class ClienteServico {
    
    public boolean cadastrarCliente(ClienteDto dados){
        return true;
    }
    
    public boolean atualizarCliente(ClienteDto dados){
        return true;
    }
}
