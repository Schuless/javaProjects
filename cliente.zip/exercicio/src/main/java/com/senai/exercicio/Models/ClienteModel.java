package com.senai.exercicio.Models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "CLIENTE")
public class ClienteModel {

    //Código do cliente.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    //Nome do cliente.
    @Column(name = "ClienteNome")
    private String nome;

    //Email do cliente.
    @Column(name = "ClienteEmail")
    private String login;

    // Número de telefone do cliente.
    @Column(name = "ClienteTelefone")
    private String telefone;

    //Data em que o cliente foi cadastrado.
    @Column(name = "ClienteDataCadastro")
    private LocalDate dataCadastro;

    //Endereço residencial do cliente.
    @Column(name = "ClienteEndereco")
    private String Endereço;

    //Número da residência do cliente.
    @Column(name = "ClienteNumeroEndereco")
    Integer numeroEndereco;

    public ClienteModel() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public LocalDate getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDate dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public String getEndereço() {
        return Endereço;
    }

    public void setEndereço(String Endereço) {
        this.Endereço = Endereço;
    }

    public Integer getNumeroEndereco() {
        return numeroEndereco;
    }

    public void setNumeroEndereco(Integer numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }
    
    

}
