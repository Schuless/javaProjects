package com.senai.exercicio.Controllers;

import com.senai.exercicio.Dtos.*;
import com.senai.exercicio.Service.ClienteServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClienteController {

    @Autowired
    ClienteServico servicoCliente;
    
    public ResponseEntity<MensagemDto> cadastrarCliente(@RequestBody ClienteDto dados) {

        boolean sucesso = servicoCliente.cadastrarCliente(dados);

        MensagemDto x = new MensagemDto();

        if (sucesso) {

            x.setMensagem("Cadastro realizado com sucesso!");
            return ResponseEntity.status(HttpStatus.CREATED).body(x);
        }
        x.setMensagem("Falha ao cadastrar cliente!");
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(x);
    }
    
    public ResponseEntity<MensagemDto> atualizarCliente(@RequestBody ClienteDto dados) {

        boolean sucesso = servicoCliente.atualizarCliente(dados);

        MensagemDto x = new MensagemDto();

        if (sucesso) {

            x.setMensagem("Cliente atualizado com sucesso!");
            return ResponseEntity.status(HttpStatus.CREATED).body(x);
        }
        x.setMensagem("Falha ao atualizar cliente!");
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(x);
    }
}
