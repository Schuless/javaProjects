package com.senai.exercicio.Dtos;

public class MensagemDto {
    
    private String mensagem;

    public MensagemDto() {
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
    
    
}
