package com.atividades.exercicio2.services;

import com.atividades.exercicio2.dtos.*;
import org.springframework.stereotype.Service;

@Service
public class conversorService {

    public ResultadoConversorDto converterTemperatura(conversorDto converter) {
        ResultadoConversorDto retorno = new ResultadoConversorDto();
        String unidade = converter.getUnidadeOrigem();
        if (unidade.equals("C")) {
            retorno.setUnidadeDestino("F");
            retorno.setUnidadeValor((converter.getUnidadeValor() * 9 / 5) + 32);     
        } else if (unidade.equals("F")) {
            retorno.setUnidadeDestino("C");
            retorno.setUnidadeValor((converter.getUnidadeValor()- 32) * 5/9);          
        } else {
            System.out.println("Erro");
        }
        return retorno;
    }
    
    public ResultadoConversorDto converterComprimento(conversorDto converter) {
        ResultadoConversorDto retorno = new ResultadoConversorDto();
        String unidade = converter.getUnidadeOrigem();
        if (unidade.equals("M")) {
            retorno.setUnidadeDestino("CM");
            retorno.setUnidadeValor(converter.getUnidadeValor() * 100);         
        } else if (unidade.equals("CM")) {
            retorno.setUnidadeDestino("M");
            retorno.setUnidadeValor(converter.getUnidadeValor() / 100);         
        } else {
            System.out.println("Erro");
        }
        return retorno;
    }
    
    public ResultadoConversorDto converterMassa(conversorDto converter) {
        ResultadoConversorDto retorno = new ResultadoConversorDto();
        String unidade = converter.getUnidadeOrigem();
        if (unidade.equals("KG")) {
            retorno.setUnidadeDestino("G");
            retorno.setUnidadeValor(converter.getUnidadeValor() * 1000);        
        } else if (unidade.equals("G")) {
            retorno.setUnidadeDestino("KG");
            retorno.setUnidadeValor(converter.getUnidadeValor() / 1000);          
        } else {
            System.out.println("Erro");
        }
        return retorno;
    }
    
    public ResultadoConversorDto converterVolume(conversorDto converter) {
        ResultadoConversorDto retorno = new ResultadoConversorDto();
        String unidade = converter.getUnidadeOrigem();
        if (unidade.equals("L")) {
            retorno.setUnidadeDestino("ML");
            retorno.setUnidadeValor(converter.getUnidadeValor() * 1000);           
        } else if (unidade.equals("ML")) {
            retorno.setUnidadeDestino("L");
            retorno.setUnidadeValor(converter.getUnidadeValor() / 1000);            
        } else {
            System.out.println("Erro");
        }
        return retorno;
    }
}

