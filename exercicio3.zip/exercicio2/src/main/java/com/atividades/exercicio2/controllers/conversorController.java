package com.atividades.exercicio2.controllers;

import com.atividades.exercicio2.dtos.*;
import com.atividades.exercicio2.services.conversorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/conversor")
public class conversorController {

    @Autowired
    conversorService converterServico;

    @PostMapping("/temperatura")
    public ResponseEntity<ResultadoConversorDto> converterTemperatura(@RequestBody conversorDto dados) {
        ResultadoConversorDto resultado = converterServico.converterTemperatura(dados);
        return ResponseEntity.ok().body(resultado);
    }
    
    @PostMapping("/comprimento")
    public ResponseEntity<ResultadoConversorDto> converterComprimento(@RequestBody conversorDto dados) {
        ResultadoConversorDto resultado = converterServico.converterComprimento(dados);
        return ResponseEntity.ok().body(resultado);
    }

    @PostMapping("/massa")
    public ResponseEntity<ResultadoConversorDto> converterMassa(@RequestBody conversorDto dados) {
        ResultadoConversorDto resultado = converterServico.converterMassa(dados);
        return ResponseEntity.ok().body(resultado);
    }

    @PostMapping("/volume")
    public ResponseEntity<ResultadoConversorDto> converterVolume(@RequestBody conversorDto dados) {
        ResultadoConversorDto resultado = converterServico.converterVolume(dados);
        return ResponseEntity.ok().body(resultado);
    }
    
}
