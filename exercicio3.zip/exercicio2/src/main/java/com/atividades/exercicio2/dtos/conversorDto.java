package com.atividades.exercicio2.dtos;

public class conversorDto {

    private String unidadeDestino;
    private String unidadeOrigem;
    private double unidadeValor;

    public conversorDto() {
    }

    public String getUnidadeDestino() {
        return unidadeDestino;
    }

    public void setUnidadeDestino(String unidadeDestino) {
        this.unidadeDestino = unidadeDestino;
    }

    public String getUnidadeOrigem() {
        return unidadeOrigem;
    }

    public void setUnidadeOrigem(String unidadeOrigem) {
        this.unidadeOrigem = unidadeOrigem;
    }

    public double getUnidadeValor() {
        return unidadeValor;
    }

    public void setUnidadeValor(double unidadeValor) {
        this.unidadeValor = unidadeValor;
    }
    
    
}
