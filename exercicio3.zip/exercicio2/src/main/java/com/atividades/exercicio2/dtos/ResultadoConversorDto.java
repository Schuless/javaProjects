package com.atividades.exercicio2.dtos;

public class ResultadoConversorDto {
    
    private String unidadeDestino;
    private double unidadeValor;
    
    public ResultadoConversorDto() {
    }

    public String getUnidadeDestino() {
        return unidadeDestino;
    }

    public void setUnidadeDestino(String unidadeDestino) {
        this.unidadeDestino = unidadeDestino;
    }
    
    public double getUnidadeValor() {
        return unidadeValor;
    }

    public void setUnidadeValor(double unidadeValor) {
        this.unidadeValor = unidadeValor;
    }
    
}
