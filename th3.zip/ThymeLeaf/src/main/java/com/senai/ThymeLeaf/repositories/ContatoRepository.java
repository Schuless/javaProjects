package com.senai.ThymeLeaf.repositories;

import com.senai.ThymeLeaf.models.ContatoModel;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContatoRepository extends JpaRepository<ContatoModel, Long>{
    
    //--Metodo que irá forçar a classe JpaRepository<UsuarioModel, Long> 
    //--implementar o select * from Usuario where UsuarioLogin = 'admin'
    public Optional<ContatoModel> findByCpf(String cpf);
    
   
}

