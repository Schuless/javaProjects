package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.AtualizarDto;
import com.senai.ThymeLeaf.dtos.UsuarioDto;
import com.senai.ThymeLeaf.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public class AtualizarUsuarioController {
    
    @Autowired
    private UsuarioService usuarioservice;
    
    @GetMapping("/atualizarusuario/{codigo}")
    public String atualizarUsuario(Model model, @PathVariable Long codigo){
        
        UsuarioDto usuarioDto = usuarioservice.obterUsuario(codigo);
        
        AtualizarDto atualizarDto = new AtualizarDto();
        atualizarDto.setCodigo(usuarioDto.getId());
        atualizarDto.setEmail(usuarioDto.getEmail());
        
        model.addAttribute("atualizarDto", atualizarDto);
        
        return "atualizarusuarios";
        
        
    }
}
