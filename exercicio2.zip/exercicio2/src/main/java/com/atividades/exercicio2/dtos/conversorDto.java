package com.atividades.exercicio2.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class conversorDto {
    @NotNull @Size(min = 1, max = 2)
    private String unidadeDestino;
    @NotNull @Size(min = 1, max = 2)
    private String unidadeOrigem;
    @NotNull
    private double unidadeValor;

    public conversorDto() {
    }

    public String getUnidadeDestino() {
        return unidadeDestino;
    }

    public void setUnidadeDestino(String unidadeDestino) {
        this.unidadeDestino = unidadeDestino;
    }

    public String getUnidadeOrigem() {
        return unidadeOrigem;
    }

    public void setUnidadeOrigem(String unidadeOrigem) {
        this.unidadeOrigem = unidadeOrigem;
    }

    public double getUnidadeValor() {
        return unidadeValor;
    }

    public void setUnidadeValor(double unidadeValor) {
        this.unidadeValor = unidadeValor;
    }
    
    
}
