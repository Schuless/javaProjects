import java.util.ArrayList;
import java.util.List;

public class PlanoTreino {

    private String descricao;
    private String nivel;
    private boolean ativo;
    private List<Exercicio> exercicios;
    private Aluno aluno;

    public PlanoTreino(String descricao, String nivel, boolean ativo) {
        if (descricao == null || descricao.isEmpty()) {
            throw new IllegalArgumentException("Plano de treino precisa de uma descrição!");
        }
        this.descricao = descricao;
        this.nivel = nivel;
        this.ativo = ativo;
        this.exercicios = new ArrayList<>();
    }

    public PlanoTreino(String descricao, String nivel) {
        this(descricao, nivel, false);
    }

    public void ativar() {
        this.ativo = true;
    }

    public void desativar() {
        this.ativo = false;
    }

    public void adicionarExercicio(Exercicio exercicio) {
        exercicios.add(exercicio);
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getResumo() {
        String exerciciosResumo = "";
        for (Exercicio e : exercicios) {
            exerciciosResumo += " - " + e.getResumo() + "\n";
        }

        return "Plano de Treino:\nDescricao: " + descricao +
                "\nNivel: " + nivel +
                "\nAtivo: " + ativo +
                "\nExercicios:\n" + exerciciosResumo +
                "-----------";
    }

}
