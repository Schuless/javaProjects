public class Aluno {

    private String nome;
    private String matricula;
    private int idade;
    private double peso;
    private double altura;
    private Instrutor instrutor;          // associação com Instrutor
    private PlanoTreino planoAtivo;       // cada aluno pode ter 0 ou 1 plano ativo

    public Aluno() {
    }

    public Aluno(String nome, String matricula, int idade, double peso, double altura) {
        if (idade < 0) {
            throw new IllegalArgumentException("Idade não pode ser negativa!");
        }
        this.nome = nome;
        this.matricula = matricula;
        this.idade = idade;
        this.peso = peso;
        this.altura = altura;
    }

    public Aluno(String nome, String matricula, int idade) {
        this(nome, matricula, idade, 0.0, 0.0);
    }

    public void setInstrutor(Instrutor instrutor) {
        this.instrutor = instrutor;
    }

    public Instrutor getInstrutor() {
        return instrutor;
    }

    public void definirPlano(PlanoTreino plano) {
        if (plano != null) {
            this.planoAtivo = plano;
            plano.setAluno(this);
        }
    }

    public PlanoTreino getPlanoAtivo() {
        return planoAtivo;
    }

    public String getResumo() {
        return "{ " + nome + " }\nMatricula: " + matricula +
                "\nIdade: " + idade +
                "\nPeso: " + peso +
                "\nAltura: " + altura +
                (instrutor != null ? "\nInstrutor: " + instrutor.getResumo() : "") +
                (planoAtivo != null ? "\nPlano Ativo: " + planoAtivo.getDescricao() : "") +
                "\n-----------";
    }

}

