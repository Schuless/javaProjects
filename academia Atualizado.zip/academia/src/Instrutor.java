import java.util.ArrayList;
import java.util.List;

public class Instrutor {

    private String nome;
    private String cref;
    private String especialidade;
    private List<Aluno> alunos;
    private Instrutor mentor;

    public Instrutor() {
    }

    public Instrutor(String nome, String cref, String especialidade) {
        if (nome == null || nome.isEmpty()) {
            throw new IllegalArgumentException("Nome do instrutor não pode ser vazio!");
        }
        if (cref == null || cref.isEmpty()) {
            throw new IllegalArgumentException("CREF inválido!");
        }
        this.nome = nome;
        this.cref = cref;
        this.especialidade = especialidade;
        this.alunos = new ArrayList<>();
    }

    public void adicionarAluno(Aluno aluno) {
        if (aluno != null) {
            alunos.add(aluno);
            aluno.setInstrutor(this);
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCref() {
        return cref;
    }

    public void setCref(String cref) {
        this.cref = cref;
    }

    public void removerAluno(Aluno aluno) {
        if (aluno != null && alunos.remove(aluno)) {
            aluno.setInstrutor(null);
        }
    }

    public void setMentor(Instrutor mentor) {
        this.mentor = mentor;
    }

    public Instrutor getMentor() {
        return mentor;
    }

    public String getResumo() {
        return "Instrutor: " + nome +
                "\nCREF: " + cref +
                "\nEspecialidade: " + especialidade +
                "\nQtd Alunos: " + alunos.size() +
                (mentor != null ? "\nMentor: " + mentor.nome : "") +
                "\n-----------";
    }
}
