public class AlunoVIP extends Aluno{

    public AlunoVIP(String nome, String matricula, int idade, double peso, double altura) {

        super(nome, matricula, idade, peso, altura);
    }

    @Override
    public String getResumo(){

        return super.getResumo() + "Acesso a treinos personalizados e sala exclusiva";
    }

}
