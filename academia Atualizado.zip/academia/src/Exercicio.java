public class Exercicio {

    private String nome;
    private int series;
    private int repeticoes;
    private double carga;

    public Exercicio(String nome, int series, int repeticoes, double carga) {
        this.nome = nome;
        this.series = series;
        this.repeticoes = repeticoes;
        this.carga = carga;
    }

    public String getResumo() {
        return nome + " - " + series + "x" + repeticoes + " @ " + carga + "kg";
    }
}


