public class Main {
    public static void main(String[] args) {

        Instrutor i1 = new Instrutor("Carlos Silva", "C12345", "Musculação");
        Instrutor i2 = new Instrutor("Ana Souza", "C67890", "Crossfit");
        i1.setMentor(i2);

        Aluno a1 = new Aluno("João", "A001", 25, 75.0, 1.80);
        Aluno a2 = new Aluno("Maria", "A002", 30);
        Aluno a3 = new Aluno("Miguel", "A003", 24, 78.0, 1.66);
        Aluno a4 = new Aluno("Arthur", "A004", 33, 80.0, 1.90);

        i1.adicionarAluno(a1);
        i1.adicionarAluno(a2);

        PlanoTreino p1 = new PlanoTreino("Treino de força", "Avançado");
        p1.adicionarExercicio(new Exercicio("Supino Reto", 3, 12, 40.0));
        p1.adicionarExercicio(new Exercicio("Agachamento Livre", 4, 10, 60.0));
        p1.adicionarExercicio(new Exercicio("Remada Curvada", 3, 12, 35.0));
        p1.ativar();

        a1.definirPlano(p1);

        InstrutorMusculacao iM = new InstrutorMusculacao("Pedro", "321312");
        iM.setMentor(i2);
        iM.adicionarAluno(a1);
        iM.adicionarAluno(a3);


        InstrutorPilates iP = new InstrutorPilates("Lucas", "312321");
        iP.setMentor(i2);
        iP.adicionarAluno(a2);
        iP.adicionarAluno(a4);

        System.out.println(i1.getResumo());
        System.out.println(i2.getResumo());
        System.out.println(a1.getResumo());
        System.out.println(a2.getResumo());
        System.out.println(p1.getResumo());
        System.out.println(iM.getResumo());
        System.out.println(iP.getResumo());





    }
}
