public class InstrutorMusculacao extends Instrutor {

    public InstrutorMusculacao(String nome, String cref) {

        super(nome, cref, "Especialista em hipertrofria Muscular");
    }

    @Override
    public String getResumo(){
        return super.getResumo();
    }

}
