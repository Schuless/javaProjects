import java.util.List;

public class InstrutorPilates extends Instrutor{

    public InstrutorPilates(String nome, String cref) {

        super(nome, cref, "Especialista em pilates");
    }

    @Override
    public String getResumo() {
        return super.getResumo();
    }
}
