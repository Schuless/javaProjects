package com.senai.cafeteria.Services;

import com.senai.cafeteria.Dtos.*;
import com.senai.cafeteria.Models.ProdutoModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service

public class ProdutoService {

    ArrayList<ProdutoModel> listaProdutos = new ArrayList<>();

    public boolean cadastrarProduto(ProdutoDto dados) {
        ProdutoModel produto = new ProdutoModel();

        for (ProdutoModel produtoItem : listaProdutos) {
            if (produtoItem.getNomeProduto().equals(dados.getNomeProduto())) {
                return false;
            }
        }
        produto.setNomeProduto(dados.getNomeProduto());
        produto.setValorProduto(dados.getValorProduto());
        produto.setCategoriaProduto(dados.getCategoriaProduto());

        listaProdutos.add(produto);

        return true;

    }

    public boolean atualizarProduto(ProdutoDto dados) {
        ProdutoModel produto = new ProdutoModel();

        for (ProdutoModel produtoItem : listaProdutos) {
            if (produtoItem.getNomeProduto().equals(dados.getNomeProduto())) {
                produto.setNomeProduto(dados.getNomeProduto());
                produto.setValorProduto(dados.getValorProduto());
                produto.setCategoriaProduto(dados.getCategoriaProduto());

                return true;
            }
        }
        return false;
    }

    public ArrayList<ProdutoDto> obterBebidas() {

        ArrayList<ProdutoDto> listaBebidas = new ArrayList<>();

        for (ProdutoModel produtoItem : listaProdutos) {
            if (produtoItem.getCategoriaProduto().equals("bebida")) {
                ProdutoDto lista = new ProdutoDto();
                lista.setNomeProduto(produtoItem.getNomeProduto());
                lista.setValorProduto(produtoItem.getValorProduto());
                lista.setCategoriaProduto(produtoItem.getCategoriaProduto());

                listaBebidas.add(lista);
            }
        }
        return listaBebidas;
    }

    public ArrayList<ProdutoDto> obterAlimentos() {
        ArrayList<ProdutoDto> listaAlimentos = new ArrayList<>();

        for (ProdutoModel produtoItem : listaProdutos) {
            if (produtoItem.getCategoriaProduto().equals("alimento")) {
                ProdutoDto lista = new ProdutoDto();
                lista.setNomeProduto(produtoItem.getNomeProduto());
                lista.setValorProduto(produtoItem.getValorProduto());
                lista.setCategoriaProduto(produtoItem.getCategoriaProduto());

                listaAlimentos.add(lista);
            }
        }
        return listaAlimentos;
    }
}
