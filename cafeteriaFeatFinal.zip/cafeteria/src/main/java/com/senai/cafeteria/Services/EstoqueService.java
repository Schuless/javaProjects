package com.senai.cafeteria.Services;

import com.senai.cafeteria.Dtos.EstoqueDto;
import com.senai.cafeteria.Models.EstoqueModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service

public class EstoqueService {

    ArrayList<EstoqueModel> listaEstoque = new ArrayList<>();

    public boolean cadastrarEstoque(EstoqueDto dados) {
        EstoqueModel estoque = new EstoqueModel();

        for (EstoqueModel produtoItem : listaEstoque) {
            //validacao para nao repetir nome, nem iniciar com estoque negativo
            if (produtoItem.getNomeProduto().equals(dados.getNomeProduto()) || (dados.getEstoqueProduto() <= 0)) {
                return false;
            }
        }
        
        estoque.setNomeProduto(dados.getNomeProduto());
        estoque.setEstoqueProduto(dados.getEstoqueProduto());

        listaEstoque.add(estoque);

        return true;

    }

    public boolean atualizarEstoque(EstoqueDto dados) {
        EstoqueModel estoque = new EstoqueModel();

        for (EstoqueModel produtoItem : listaEstoque) {
            if (produtoItem.getNomeProduto().equals(dados.getNomeProduto())) {
                //validar para nao colocar um numero de estoque negativo
                if (dados.getEstoqueProduto() >= 0) {
                    estoque.setNomeProduto(dados.getNomeProduto());
                    estoque.setEstoqueProduto(dados.getEstoqueProduto());

                    return true;
                }
            }
        }
        return false;
    }

    public ArrayList<EstoqueDto> obterItensEstoque() {

        ArrayList<EstoqueDto> listaEstocados = new ArrayList<>();

        for (EstoqueModel produtoItem : listaEstoque) {
            //verifica se o produto possui uma ou mais unidades em estoque
            if (produtoItem.getEstoqueProduto() > 0) {
                EstoqueDto lista = new EstoqueDto();
                lista.setNomeProduto(produtoItem.getNomeProduto());
                lista.setEstoqueProduto(produtoItem.getEstoqueProduto());

                listaEstocados.add(lista);
            }
        }
        return listaEstocados;
    }

    public ArrayList<EstoqueDto> obterItensEsgotados() {

        ArrayList<EstoqueDto> listaEsgotados = new ArrayList<>();

        for (EstoqueModel produtoItem : listaEstoque) {
            //verifica se o produto possui estoque igual a zero
            if (produtoItem.getEstoqueProduto() == 0) {
                EstoqueDto lista = new EstoqueDto();
                lista.setNomeProduto(produtoItem.getNomeProduto());
                lista.setEstoqueProduto(produtoItem.getEstoqueProduto());

                listaEsgotados.add(lista);
            }
        }
        return listaEsgotados;
    }
}
