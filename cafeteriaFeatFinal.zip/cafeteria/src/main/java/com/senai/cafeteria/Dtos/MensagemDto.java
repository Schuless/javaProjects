package com.senai.cafeteria.Dtos;

public class MensagemDto {

    
    private String mensagem;

    public MensagemDto() {
    }

    public MensagemDto(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
}


