package com.senai.cafeteria.Controllers;

import com.senai.cafeteria.Dtos.*;
import com.senai.cafeteria.Services.EstoqueService;
import jakarta.validation.Valid;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class EstoqueController {

    @Autowired
    private EstoqueService servicoEstoque;

    @PostMapping
    public ResponseEntity<MensagemDto> cadastrarEstoque(@Valid @RequestBody EstoqueDto dados) {
        boolean sucesso = servicoEstoque.cadastrarEstoque(dados);
        MensagemDto resposta = new MensagemDto();

        if (sucesso) {
            resposta.setMensagem("Estoque cadastrado com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao cadastrar estoque do produto!");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resposta);
        }
    }

    @PutMapping
    public ResponseEntity<MensagemDto> atualizarEstoque(@Valid @RequestBody EstoqueDto dados) {
        boolean sucesso = servicoEstoque.atualizarEstoque(dados);
        MensagemDto resposta = new MensagemDto();

        if (sucesso) {
            resposta.setMensagem("Estoque atualizado com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao atualizar o estoque do produto!");
            return ResponseEntity.ok(resposta);
        }
    }

    @GetMapping("/estoque")
    public ArrayList<EstoqueDto> obterItensEstoque() {
        
        ArrayList<EstoqueDto> itensEstocados = servicoEstoque.obterItensEstoque();
        
        return itensEstocados;
    }

    @GetMapping("/esgotado")
    public ArrayList<EstoqueDto> obterItensEsgotados() {
        
        ArrayList<EstoqueDto> itensEsgotados = servicoEstoque.obterItensEsgotados();
        
        return itensEsgotados;
    }
}
